var class_tcp_server =
[
    [ "TcpServer", "class_tcp_server.html#a05206a1d832f1a73e5d8920a2ecfed0f", null ],
    [ "~TcpServer", "class_tcp_server.html#a728a9e31c53cf86887f1f6149b1c46dd", null ],
    [ "getMessage", "class_tcp_server.html#a8e881dfe01bfb9b3b979778cbd1d60bf", null ],
    [ "runServer", "class_tcp_server.html#a0c88699ee252b183225701b1c3d6854b", null ],
    [ "sendMessage", "class_tcp_server.html#a17d13bb31a5f2926caa030d9914257fb", null ]
];