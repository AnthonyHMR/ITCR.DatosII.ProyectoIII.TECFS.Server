var struct_node =
[
    [ "Node", "struct_node.html#ad7a34779cad45d997bfd6d3d8043c75f", null ],
    [ "code", "struct_node.html#a57de6ba3caffcb1f7330d561fa4dfbb6", null ],
    [ "data", "struct_node.html#a94c9686e27f05bedd604d347d5bad449", null ],
    [ "freq", "struct_node.html#a6bcfa8fea1ef81ca0fb8473ae08cd654", null ],
    [ "left", "struct_node.html#ab8c667ac8fdb120ed4c031682a9cdaee", null ],
    [ "right", "struct_node.html#afe5916d969cd32f7de1e4ba15580c989", null ]
];