var annotated_dup =
[
    [ "Class", "class_class.html", null ],
    [ "Controller", "class_controller.html", null ],
    [ "ControllerNode", "class_controller_node.html", "class_controller_node" ],
    [ "huffman", "classhuffman.html", "classhuffman" ],
    [ "Node", "struct_node.html", "struct_node" ],
    [ "Server", "class_server.html", null ],
    [ "TcpServer", "class_tcp_server.html", "class_tcp_server" ]
];