var class_controller_node =
[
    [ "ControllerNode", "class_controller_node.html#ae6df5e7f4154cc81455c136c580c98d1", null ],
    [ "receiveBook", "class_controller_node.html#a5c7500d82ac9ebeb724ead1508b7ad10", null ],
    [ "searchBook", "class_controller_node.html#ab12c22890ec3d3b392a22f3177798855", null ]
];