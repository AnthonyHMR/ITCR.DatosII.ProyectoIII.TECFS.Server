var classhuffman =
[
    [ "huffman", "classhuffman.html#af944f02ee0bced925b81a9f918f9db65", null ],
    [ "compress", "classhuffman.html#a234375497022ea32f1f60c343aa24596", null ],
    [ "decompress", "classhuffman.html#a7f2233ac8b06790e50a9e5f67f49f840", null ]
];