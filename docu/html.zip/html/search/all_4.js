var searchData=
[
  ['node_8',['Node',['../struct_node.html',1,'Node'],['../struct_node.html#ad7a34779cad45d997bfd6d3d8043c75f',1,'Node::Node()']]]
];
