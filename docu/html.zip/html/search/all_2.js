var searchData=
[
  ['getmessage_6',['getMessage',['../class_tcp_server.html#a8e881dfe01bfb9b3b979778cbd1d60bf',1,'TcpServer']]]
];
