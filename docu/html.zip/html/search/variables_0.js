var searchData=
[
  ['data_34',['data',['../struct_node.html#a94c9686e27f05bedd604d347d5bad449',1,'Node']]]
];
